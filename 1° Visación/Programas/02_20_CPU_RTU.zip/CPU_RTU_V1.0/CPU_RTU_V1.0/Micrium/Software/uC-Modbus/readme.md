# uC/Modbus

µC/Modbus provides an embedded solution for implementing Modbus, an industrial communications protocol used for connecting industrial electronic devices.

## For the complete documentation, visit https://doc.micrium.com/display/ucos/