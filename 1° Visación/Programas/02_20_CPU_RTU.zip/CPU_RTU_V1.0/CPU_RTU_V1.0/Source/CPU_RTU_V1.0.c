/*
===============================================================================
 Name        : CPU_RTU_V1.0.c
 Author      : $(author)
 Version     :
 Copyright   : $(copyright)
 Description : main definition
===============================================================================
*/

/* Includes */

#include "chip.h"
#include <app_cfg.h>
#include <cpu_core.h>
#include <os.h>
#include <cr_section_macros.h>


/* Defines */

#define PORT(X)		X
#define PIN(X)		X

#define MAX_I2C_SLAVES	8u
#define ANALOG_IN_MAX	4u

/* Variables Globales */

INT8U Entrada_Analogica_1[2] = { 0x00 , 0x00 };
INT8U Entrada_Analogica_2[2] = { 0x00 , 0x00 };
INT8U Entrada_Analogica_3[2] = { 0x00 , 0x00 };
INT8U Entrada_Analogica_4[2] = { 0x00 , 0x00 };

/* Prototipos de Funciones */

void Configuracion_GPIO(void);
void Configuracion_I2C(void);
void Configuracion_UART(void);

static  void  App_TaskCreate (void);


/* Declaracion de Tareas */

static void StartupTask			(void *p_arg);
static void DigitalInputTask	(void *p_arg);
static void DigitalOutputTask	(void *p_arg);
static void AnalogInputTask		(void *p_arg);

static OS_STK StartupTaskStk[APP_CFG_STARTUP_TASK_STK_SIZE];
static OS_STK DigitalInputTaskStk[APP_CFG_DIGITAL_INPUT_TASK_STK_SIZE];
static OS_STK DigitalOutputTaskStk[APP_CFG_DIGITAL_OUTPUT_TASK_STK_SIZE];
static OS_STK AnalogInputTaskStk[APP_CFG_ANALOG_INPUT_TASK_STK_SIZE];


#warning "Modify this value to match the number of external interrupts in your MCU"
#define EXT_INT_MAX_NBR 16u


int main(void) {

	#if (OS_TASK_NAME_EN > 0u)
	CPU_INT08U os_err;
	#endif
	CPU_INT16U int_id;

	CPU_IntDis();

	for (int_id = CPU_INT_EXT0; int_id <= (EXT_INT_MAX_NBR - 1u); int_id++)
	{
		/* Set all external intr. to KA interrupt priority boundary */
		CPU_IntSrcPrioSet(int_id, CPU_CFG_KA_IPL_BOUNDARY, CPU_INT_KA);
	}

    /* Read clock settings and update SystemCoreClock variable */
    SystemCoreClockUpdate();

    /* Configuracion de perifericos */
    Configuracion_GPIO();
    Configuracion_I2C();
    Configuracion_UART();

    OSInit();

      /*  Creacion de tarea StartupTask  */

    OSTaskCreateExt( StartupTask,
                     0,
					 &StartupTaskStk[APP_CFG_STARTUP_TASK_STK_SIZE - 1],
					 APP_CFG_STARTUP_TASK_PRIO,
					 APP_CFG_STARTUP_TASK_PRIO,
					 &StartupTaskStk[0],
					 APP_CFG_STARTUP_TASK_STK_SIZE,
					 0,
					 (OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR) );

   	 #if (OS_TASK_NAME_EN > 0u)
     OSTaskNameSet( APP_CFG_STARTUP_TASK_PRIO, (INT8U *)"Startup task", &os_err);
     #endif

     OSStart();

    while(1) {

    }
    return 0 ;
}

void Configuracion_GPIO(void)
{

	/* Configuracion SCU */

	Chip_SCU_PinMuxSet(PORT(2), PIN(0), SCU_MODE_PULLUP | SCU_MODE_INBUFF_EN | SCU_MODE_FUNC4);
	Chip_SCU_PinMuxSet(PORT(2), PIN(1), SCU_MODE_PULLUP | SCU_MODE_INBUFF_EN | SCU_MODE_FUNC4);
	Chip_SCU_PinMuxSet(PORT(2), PIN(2), SCU_MODE_PULLUP | SCU_MODE_INBUFF_EN | SCU_MODE_FUNC4);
	Chip_SCU_PinMuxSet(PORT(2), PIN(10), SCU_MODE_PULLUP | SCU_MODE_INBUFF_EN | SCU_MODE_FUNC0);
	Chip_SCU_PinMuxSet(PORT(2), PIN(11), SCU_MODE_PULLUP | SCU_MODE_INBUFF_EN | SCU_MODE_FUNC0);
	Chip_SCU_PinMuxSet(PORT(2), PIN(12), SCU_MODE_PULLUP | SCU_MODE_INBUFF_EN | SCU_MODE_FUNC0);

	Chip_SCU_PinMuxSet(PORT(1), PIN(6), SCU_MODE_INACT | SCU_MODE_INBUFF_EN | SCU_MODE_FUNC0);

	/* Configuracion GPIO */

	Chip_GPIO_Init(LPC_GPIO_PORT);

	Chip_GPIO_SetPinDIROutput(LPC_GPIO_PORT, PORT(5), PIN(0));
	Chip_GPIO_SetPinState(LPC_GPIO_PORT, PORT(5), PIN(0), (bool) false);
	Chip_GPIO_SetPinDIROutput(LPC_GPIO_PORT, PORT(5), PIN(1));
	Chip_GPIO_SetPinState(LPC_GPIO_PORT, PORT(5), PIN(1), (bool) false);
	Chip_GPIO_SetPinDIROutput(LPC_GPIO_PORT, PORT(5), PIN(2));
	Chip_GPIO_SetPinState(LPC_GPIO_PORT, PORT(5), PIN(2), (bool) false);
	Chip_GPIO_SetPinDIROutput(LPC_GPIO_PORT, PORT(0), PIN(14));
	Chip_GPIO_SetPinState(LPC_GPIO_PORT, PORT(0), PIN(14), (bool) false);
	Chip_GPIO_SetPinDIROutput(LPC_GPIO_PORT, PORT(1), PIN(11));
	Chip_GPIO_SetPinState(LPC_GPIO_PORT, PORT(1), PIN(11), (bool) false);
	Chip_GPIO_SetPinDIROutput(LPC_GPIO_PORT, PORT(1), PIN(12));
	Chip_GPIO_SetPinState(LPC_GPIO_PORT, PORT(1), PIN(12), (bool) false);

	Chip_GPIO_SetPinDIRInput(LPC_GPIO_PORT, PORT(1), PIN(9));

}

void Configuracion_I2C(void)
{

	Chip_SCU_I2C0PinConfig( I2C0_STANDARD_FAST_MODE );

	Chip_I2C_SetClockRate( I2C0 , 100000);

	Chip_I2C_SetMasterEventHandler( I2C0 , Chip_I2C_EventHandlerPolling);

	Chip_I2C_Init(I2C0);

}

void Configuracion_UART(void)
{

	Chip_SCU_PinMux(PORT(2), PIN(3), SCU_MODE_INACT, SCU_MODE_FUNC2);
	Chip_SCU_PinMux(PORT(2), PIN(4), SCU_MODE_INACT | SCU_MODE_INBUFF_EN | SCU_MODE_ZIF_DIS, SCU_MODE_FUNC2);

	Chip_UART_Init(LPC_USART3);

	Chip_UART_SetBaud(LPC_USART3, 9600);

	Chip_UART_ConfigData(LPC_USART3, UART_LCR_WLEN8		|
									 UART_LCR_SBS_1BIT 	|
									 UART_LCR_PARITY_DIS ); 		/* 8N1 */

	Chip_UART_SetupFIFOS(LPC_USART3,   UART_FCR_FIFO_EN	|
									   UART_FCR_RX_RS	|
									   UART_FCR_TX_RS	|
									   UART_FCR_TRG_LEV2 );

	Chip_UART_TXEnable(LPC_USART3);

}

/*
*********************************************************************************************************
*                                          StartupTask()
*
* Description : Es la tarea de inicialización.
*
* Argument(s) : p_arg       Argument passed to 'StartupTask()' by 'OSTaskCreate()'.
*
* Return(s)   : none.
*
* Caller(s)   : This is a task.
*
* Note(s)     : none.
*********************************************************************************************************
*/

static void StartupTask (void *p_arg)
{
	CPU_INT32U cpu_clk;

	(void)p_arg;

	cpu_clk = Chip_Clock_GetRate(CLK_MX_MXCORE);

	/* Initialize and enable System Tick timer */
	OS_CPU_SysTickInitFreq(cpu_clk);

 	#if (OS_TASK_STAT_EN > 0)
	OSStatInit();                                     /* Determine CPU capacity */
 	#endif

	// App_EventCreate();                             /* Create application events */
	App_TaskCreate();                          	      /* Create application tasks */

	OSTaskDel(OS_PRIO_SELF);

 while (DEF_TRUE)
 {

 }
}

/*
*********************************************************************************************************
*                                          DigitalInputTask()
*
* Description : Es la tarea para la lectura de los Modulos de Entradas Digitales a traves de I2C.
*
* Argument(s) : p_arg       Argument passed to 'DigitalInputTask()' by 'OSTaskCreate()'.
*
* Return(s)   : none.
*
* Caller(s)   : This is a task.
*
* Note(s)     : none.
*********************************************************************************************************
*/

static void DigitalInputTask (void *p_arg)
{

	(void)p_arg;

	INT8U Entradas_Digitales = 0x00;

	INT8U Send_Buffer[9];

	INT8U Cnt_I2C = 0;

	INT8U Slave_Address[MAX_I2C_SLAVES] = { 0x00 , 0x00 , 0x00 , 0x00 ,0x00 , 0x00 , 0x00 , 0x27};

	while (DEF_TRUE)
	{

		Chip_GPIO_SetPinToggle(LPC_GPIO_PORT, 0, 14);

		for( Cnt_I2C = 0 ; Cnt_I2C <= MAX_I2C_SLAVES-1 ; Cnt_I2C++ )
		{

			if ( Slave_Address[Cnt_I2C] != 0x00 )
			{
				Chip_I2C_MasterRead(I2C0 , Slave_Address[Cnt_I2C] , &Entradas_Digitales, 1);
				//Chip_UART_Send( LPC_USART3, &Entradas_Digitales, sizeof(Entradas_Digitales) );
			}
		}
		Send_Buffer[0] = Entradas_Digitales;
		Send_Buffer[1] = Entrada_Analogica_1[0];
		Send_Buffer[2] = Entrada_Analogica_1[1];
		Send_Buffer[3] = Entrada_Analogica_2[0];
		Send_Buffer[4] = Entrada_Analogica_2[1];
		Send_Buffer[5] = Entrada_Analogica_3[0];
		Send_Buffer[6] = Entrada_Analogica_3[1];
		Send_Buffer[7] = Entrada_Analogica_4[0];
		Send_Buffer[8] = Entrada_Analogica_4[1];
		Chip_UART_SendBlocking( LPC_USART3, &Send_Buffer[0], 9 );

	 OSTimeDly(1000);
	}

}

/*
*********************************************************************************************************
*                                          DigitalOutputTask()
*
* Description : Es la tarea para la escritura de los Modulos de Salidas Digitales a traves de I2C.
*
* Argument(s) : p_arg       Argument passed to 'DigitalOutputTask()' by 'OSTaskCreate()'.
*
* Return(s)   : none.
*
* Caller(s)   : This is a task.
*
* Note(s)     : none.
*********************************************************************************************************
*/

static void DigitalOutputTask (void *p_arg)
{

	(void)p_arg;

	INT8U Salidas_Digitales = 0x00;

	INT8U Cnt_I2C = 0;

	INT8U Slave_Address[MAX_I2C_SLAVES] = { 0x00 , 0x00 , 0x00 , 0x00 ,0x00 , 0x00 , 0x26 , 0x00};

	while (DEF_TRUE)
	{
		Chip_GPIO_SetPinToggle(LPC_GPIO_PORT, 1, 11);

		for( Cnt_I2C = 0 ; Cnt_I2C <= MAX_I2C_SLAVES-1 ; Cnt_I2C++ )
		{

			if ( Slave_Address[Cnt_I2C] != 0x00 )
			{
				Chip_UART_ReadBlocking(LPC_USART3, &Salidas_Digitales, sizeof(Salidas_Digitales));
				Chip_I2C_MasterSend(I2C0, Slave_Address[Cnt_I2C], &Salidas_Digitales, 1);
			}
		}

	 OSTimeDly(1000);
	}

}

/*
*********************************************************************************************************
*                                          AnalogInputTask()
*
* Description : Es la tarea para lectura de los Modulos de Entradas Analógicas a traves de I2C.
*
* Argument(s) : p_arg       Argument passed to 'AnalogInputTask()' by 'OSTaskCreate()'.
*
* Return(s)   : none.
*
* Caller(s)   : This is a task.
*
* Note(s)     : none.
*********************************************************************************************************
*/

static void AnalogInputTask (void *p_arg)
{

	(void)p_arg;

	//INT16U ADC1 = 0x0000;
	//INT16U ADC2 = 0x0000;
	//INT16U ADC3 = 0x0000;
	//INT16U ADC4 = 0x0000;

	//INT8U Limite1 = 0;
	//INT8U Limite2 = 0;
	//INT8U Limite3 = 0;
	//INT8U Limite4 = 0;

	INT8U Cnt_An = 0;
	INT8U Cnt_I2C = 0;

	INT8U Slave_Address[MAX_I2C_SLAVES] = { 0x00 , 0x00 , 0x00 , 0x00 ,0x00 , 0x25 , 0x00 , 0x00};

	while (DEF_TRUE)
	{

		Chip_GPIO_SetPinToggle(LPC_GPIO_PORT, 1, 12);

		for( Cnt_I2C = 0 ; Cnt_I2C <= MAX_I2C_SLAVES-1 ; Cnt_I2C++ )
		{

			if ( Slave_Address[Cnt_I2C] != 0x00 )
			{
				for( Cnt_An = 1 ; Cnt_An <= ANALOG_IN_MAX ; Cnt_An++ )
				{
					if(Cnt_An == 1)
					{
					   	Chip_I2C_MasterSend(I2C0 , Slave_Address[Cnt_I2C] , &Cnt_An , 1);
					   	Chip_I2C_MasterRead(I2C0 , Slave_Address[Cnt_I2C] , &Entrada_Analogica_1[0], 2);
					}
					if(Cnt_An == 2)
					{
					   	Chip_I2C_MasterSend(I2C0 , Slave_Address[Cnt_I2C] , &Cnt_An , 1);
					    Chip_I2C_MasterRead(I2C0 , Slave_Address[Cnt_I2C] , &Entrada_Analogica_2[0], 2);
					}
					if(Cnt_An == 3)
					{
					  	Chip_I2C_MasterSend(I2C0 , Slave_Address[Cnt_I2C] , &Cnt_An , 1);
					    Chip_I2C_MasterRead(I2C0 , Slave_Address[Cnt_I2C] , &Entrada_Analogica_3[0], 2);
					}
					if(Cnt_An == 4)
					{
					   	Chip_I2C_MasterSend(I2C0 , Slave_Address[Cnt_I2C] , &Cnt_An , 1);
					   	Chip_I2C_MasterRead(I2C0 , Slave_Address[Cnt_I2C] , &Entrada_Analogica_4[0], 2);
					}
				}
			}
		}

		//Limite1 = (Entrada_Analogica_1[0] >> 2) & 0x01;
		//Limite2 = (Entrada_Analogica_2[0] >> 2) & 0x01;
		//Limite3 = (Entrada_Analogica_3[0] >> 2) & 0x01;
		//Limite4 = (Entrada_Analogica_4[0] >> 2) & 0x01;

		//ADC1 = ((Entrada_Analogica_1[0] << 8) & 0x0300) | (Entrada_Analogica_1[1] & 0x00FF);
		//ADC2 = ((Entrada_Analogica_2[0] << 8) & 0x0300) | (Entrada_Analogica_2[1] & 0x00FF);
		//ADC3 = ((Entrada_Analogica_3[0] << 8) & 0x0300) | (Entrada_Analogica_3[1] & 0x00FF);
		//ADC4 = ((Entrada_Analogica_4[0] << 8) & 0x0300) | (Entrada_Analogica_4[1] & 0x00FF);

	 OSTimeDly(1000);
	}

}

/*
*********************************************************************************************************
*                                            App_TaskCreate()
*
* Description : Create the application tasks.
*
* Argument(s) : none.
*
* Return(s)   : none.
*
* Caller(s)   : StartupTask().
*
* Note(s)     : none.
*********************************************************************************************************
*/

static  void  App_TaskCreate (void)
{

	CPU_INT08U  os_err;

      /* Creacion de tarea para la lectura de los Modulos de Entradas Digitales a traves de I2C */

      os_err = OSTaskCreateExt((void (*)(void *)) DigitalInputTask,
                               (void          * ) 0,
                               (OS_STK        * )&DigitalInputTaskStk[APP_CFG_DIGITAL_INPUT_TASK_STK_SIZE - 1],
                               (INT8U           ) APP_CFG_DIGITAL_INPUT_TASK_PRIO,
                               (INT16U          ) APP_CFG_DIGITAL_INPUT_TASK_PRIO,
                               (OS_STK        * )&DigitalInputTaskStk[0],
                               (INT32U          ) APP_CFG_DIGITAL_INPUT_TASK_STK_SIZE,
                               (void          * ) 0,
                               (INT16U          )(OS_TASK_OPT_STK_CLR | OS_TASK_OPT_STK_CHK));

      #if (OS_TASK_NAME_EN > 0u)
       	   OSTaskNameSet(APP_CFG_DIGITAL_INPUT_TASK_PRIO, (INT8U *)"DigitalInput Task", &os_err);
      #endif

       /* Creacion de tarea para la escritura de los Modulos de Salidas Digitales a traves de I2C */

       os_err = OSTaskCreateExt((void (*)(void *)) DigitalOutputTask,
                                (void          * ) 0,
                                (OS_STK        * )&DigitalOutputTaskStk[APP_CFG_DIGITAL_OUTPUT_TASK_STK_SIZE - 1],
                                (INT8U           ) APP_CFG_DIGITAL_OUTPUT_TASK_PRIO,
                                (INT16U          ) APP_CFG_DIGITAL_OUTPUT_TASK_PRIO,
                                (OS_STK        * )&DigitalOutputTaskStk[0],
                                (INT32U          ) APP_CFG_DIGITAL_OUTPUT_TASK_STK_SIZE,
                                (void          * ) 0,
                                (INT16U          )(OS_TASK_OPT_STK_CLR | OS_TASK_OPT_STK_CHK));

       #if (OS_TASK_NAME_EN > 0u)
       	   OSTaskNameSet(APP_CFG_DIGITAL_OUTPUT_TASK_PRIO, (INT8U *)"DigitalOutput Task", &os_err);
       #endif

       /* Creacion de tarea para lectura de los Modulos de Entradas Analógicas a traves de I2C */

       os_err = OSTaskCreateExt((void (*)(void *)) AnalogInputTask,
                                (void          * ) 0,
                                (OS_STK        * )&AnalogInputTaskStk[APP_CFG_ANALOG_INPUT_TASK_STK_SIZE - 1],
                                (INT8U           ) APP_CFG_ANALOG_INPUT_TASK_PRIO,
                                (INT16U          ) APP_CFG_ANALOG_INPUT_TASK_PRIO,
                                (OS_STK        * )&AnalogInputTaskStk[0],
                                (INT32U          ) APP_CFG_ANALOG_INPUT_TASK_STK_SIZE,
                                (void          * ) 0,
                                (INT16U          )(OS_TASK_OPT_STK_CLR | OS_TASK_OPT_STK_CHK));

       #if (OS_TASK_NAME_EN > 0u)
           OSTaskNameSet(APP_CFG_ANALOG_INPUT_TASK_PRIO, (INT8U *)"AnalogInput Task", &os_err);
       #endif

}
